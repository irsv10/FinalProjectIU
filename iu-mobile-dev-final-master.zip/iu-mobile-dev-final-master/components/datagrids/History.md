1.1.0 2014-09-10
================
upgrade to bootstrap 3

1.0.16 2014-06-09
==================
DE231 - Fixed clicked state background color for datagrid row

1.0.0 / 2014-03-03
===============
* code refactored for hdx 1.2.0

0.11.0
==================
* Use bower-optimized dependency libraries


0.9.1 / 2013-12-4
==================
* Pull out hover color and selected color into vars - Make sure to update vars in IIDx and MDX when using this version
* Break out themes inside component for HDX vs IIDX needed for module dependency



0.6.0 / 2013-07-07
==================
* Migrate off require-jquery
* Migrate to Bootstrap 2.3.2
