# Datagrids

npm install
bower install
grunt

//optional: inorder for the ajax calls to work properly, you can use the node static http-server to get around the ajax calls.

http-server