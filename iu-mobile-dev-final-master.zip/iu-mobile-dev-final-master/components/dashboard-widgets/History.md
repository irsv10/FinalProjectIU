0.9.2 / 2014-09-10
==================
* upgrade to bootstrap 3.x

0.8.1 / 2014-05-07
==================
* updated path to github

0.8.0 / 2014-03-05
===================
* Refactored to separate hdx/iidx themes.

0.7.1 / 2014-03-21
==================
* Before merging hdx 1.2.0


0.5.0 / 2013-07-07
==================
* Migrate off require-jquery
* Migrate to Bootstrap 2.3.2


