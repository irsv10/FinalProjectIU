2.6.2 
============================
Bootstrap upgrade to 3.X

2.5.15 2014-07-22
===========================
Added ge logo images for sign in screen

2.5.14 2014-06-10
===========================
Fixed bg color for labels and badges

2.5.13 2014-06-09
============================
de231 Fixed hover state on datagrid row

2.5.8 2014-06-04
==================
de217 fixed underline issue for icon

2.5.7 2014-06-3
================
de138 pagination fix for hdx

2.5.5 2014-05-30
================
Envelope glyph font fix

2.5.4 2014-05-30
================
Added Warning Label and remapped Font Awesome icon-time to the new scheduler icon

2.5.1 2014-05-24
================
Added Font Awesome Bootstrap CSS Helpers to smooth over some icon contexts

2.5.0 2014-05-24
================
Remove Font Awesome, add new replacement icons to GE-Iconography

2.4.14 May 22, 2014
================
Added background color for slider for lights off mode

2.4.8 / 2014-04-08
==================
* added offBlack color for HDx brand - lights off mode

2.4.7 / 2014-04-08
==================
* edited Accent palette for HDx theme for fixing charts and sparkline issues.

2.4.0 / 2014-03-18
===================
* added hdx theme


2.3.1 / 2014-1-22
==================
* GESans 1.0 and GESerif 1.0 web fonts
* GE Inspira Bold Italic was broken previously
* Separated fonts.less from main brandkit.less file so that we can compile without fonts (for Typekit)
* Removed Meta Serif font

2.0.2 / 2013-11-05
==================
* GESans 1.0 and GESerif 1.0

2.0.1 / 2013-11-05
==================
* GE Brand Refresh
=======

0.3.0 / 2013-07-05
==================
* Include @inputDisabledText
