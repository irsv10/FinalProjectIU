1.2.4 / 2014-05-06
==================
* Updated path to github

1.2.3 / 2014-04-17
==================
* Refactoring for hdx/iidx theme and adding threshold barchart


1.2.2 / 2014-03-25
==================
* provide brandkit theming support for IIDX vs HDX
* todo: add lights off support if we need it (i'm not sure that we do)


1.2.0 / 2014-03-20
==================
* merged hdx1.2.0 with master with new structure

0.7.0 / 2013-11-18
==================
* Pulled theme into main require config definition because there was no way to swap out the theme as is. Now, "charts-theme" must be defined in
  the design system and will propogate to charts to use the desired theme


0.3.0 / 2013-07-05
==================
* Migrate off require-jquery


