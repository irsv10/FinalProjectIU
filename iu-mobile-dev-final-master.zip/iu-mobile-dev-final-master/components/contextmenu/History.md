0.3.1 / 2013-08-23
==================
* Updated component server to current server

0.2.0 / 2013-07-05
==================
* Added js/contextmenu.js to shim jQuery-contextMenu
* Migrate off require-jquery
* Migrate to Bootstrap 2.3.2

0.1.2 / 2013-06-17
==================

* Updated Documentation
* Initial commit of contextMenu

